var searchData=
[
  ['endgame_5',['EndGame',['../class_text_display.html#adc44a95b890015e88f1a9d308cf26449',1,'TextDisplay']]]
];
